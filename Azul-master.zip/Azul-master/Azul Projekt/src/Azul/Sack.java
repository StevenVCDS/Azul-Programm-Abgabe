package Azul;

public class Sack {


	public Flie�en[] flie�enImSack = new Flie�en[80];
	
	public Sack(Flie�en[] imSack)
	{
		this.flie�enImSack = imSack;
		
	}
}
